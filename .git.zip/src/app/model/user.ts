export class User {
  id;
  name;
  family;
  email;
  password;
  type;
  phone;
  active;
}




