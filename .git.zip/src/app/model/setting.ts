export class SiteSetting {
  SiteId;
  Time;
  TypeSchedule;
  DayOfMounth;
  LenghtToScraping;
  ScheduleTime;
  String;
}
export class PortToPort{
  from;
  to;
  siteId;
}
export class SystemEmail {
  email;
  server;
  port;
  username;
  password;
}
export class ScrapReport{
  from;
  to;
  fromTime;
  toTime;
}
